<template>
  <p>home page</p>
</template>

<script>
	export default {
		// middleware: ['auth']
	}
</script>
