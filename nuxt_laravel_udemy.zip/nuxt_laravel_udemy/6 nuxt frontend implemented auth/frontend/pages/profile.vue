<template>
	<div>
		<h2>User Profile page</h2>
	</div>
</template>