export default function({ store }) {
	store.dispatch("validation/clearErrors");
}
